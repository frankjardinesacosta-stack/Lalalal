import SwiftUI
import UIKit
import AVFoundation
import Security

@MainActor
enum PantherFeedbackAudio {
    static var player: AVAudioPlayer?
    static func play(_ name: String) {
        guard let url = Bundle.main.url(forResource: name, withExtension: "m4a") else {
            print("Audio no encontrado en el bundle: \(name).m4a")
            return
        }
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true)
            player = try AVAudioPlayer(contentsOf: url)
            player?.prepareToPlay()
            player?.play()
        } catch {
            print("No se pudo reproducir el audio: \(error.localizedDescription)")
        }
    }
}


@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var pantherSession = PantherSession()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var showOnboarding = false
    @State private var calculatorUnlocked = false
    @State private var showAttribution = false
    @State private var updateOffer: AppUpdateChecker.Offer?
    @State private var selectedPatchGame: PatchGameMode?
    @Environment(\.scenePhase) private var scenePhase

    init() {
        setupLogCapture()
        log("app: 3105 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
            ZStack {
                Group {
                    #if DEBUG_PATCHES
                    // Development-only UI preview. No key, role or server permissions are granted.
                    PatchProjectsView(ghostTheme: true)
                        .background(Color.black.ignoresSafeArea())
                        .statusBarHidden(true)
                    #else
                    if pantherSession.role == nil {
                        PantherCalculatorView(session: pantherSession)
                    } else if pantherSession.role == "patches" {
                        if let selected = selectedPatchGame {
                            PantherAssignedPatchesView(
                                session: pantherSession,
                                gameMode: selected,
                                onBack: {
                                    withAnimation(.easeInOut(duration: 0.22)) {
                                        selectedPatchGame = nil
                                    }
                                }
                            )
                        } else {
                            PatchGameSelectorView { game in
                                withAnimation(.easeInOut(duration: 0.22)) { selectedPatchGame = game }
                            }
                        }
                    } else {
                        ContentView()
                    }
                    #endif
                }
                    .environmentObject(appState)
                    .environmentObject(pantherSession)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .opacity(showOnboarding && pantherSession.role != nil ? 0 : 1)
                    .allowsHitTesting(!showOnboarding || pantherSession.role == nil)

                if false && showOnboarding && pantherSession.role != nil {
                    OnboardingView {
                        OnboardingStore.markCompleted()
                        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
                            showOnboarding = false
                        }
                        appState.detectSupport()
                        // Automatic update prompt disabled.
                    }
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .transition(.opacity.combined(with: .scale(scale: 0.98)))
                    .zIndex(1)
                }
            }
            .displayIdentityAttribution(isPresented: $showAttribution, enabled: !showOnboarding && pantherSession.role == "admin")
            .sheet(isPresented: $showAttribution) {
                DisplayAttributionSheet()
            }
            .alert(item: $updateOffer) { offer in
                Alert(
                    title: Text(language.text("update.title")),
                    message: Text(language.text("update.message", offer.version)),
                    primaryButton: .default(Text(language.text("update.agree"))) {
                        // No external GitHub navigation from the patch menu.
                    },
                    secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                        AppUpdateChecker.dismiss(version: offer.version)
                    }
                )
            }
            .task {
                await pantherSession.restoreSavedKey()
            }
            .onAppear {
                if !showOnboarding && pantherSession.role != nil {
                    appState.detectSupport()
                    // Automatic update prompt disabled.
                }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active, !showOnboarding, pantherSession.role != nil else { return }
                appState.detectSupport()
            }
            .task(id: pantherSession.role) {
                // Re-check the active key with Lovable every 30 seconds while logged in.
                // SwiftUI cancels this task automatically when the role changes.
                guard pantherSession.role != nil else { return }
                PantherBundledPackages.installIfNeeded()
                await pantherSession.revalidate()
                while !Task.isCancelled && pantherSession.role != nil {
                    do {
                        try await Task.sleep(nanoseconds: 30_000_000_000)
                    } catch { break }
                    guard !Task.isCancelled, pantherSession.role != nil else { break }
                    await pantherSession.revalidate()
                }
            }
            .onChange(of: scenePhase) { phase in
                if phase == .active { Task { await pantherSession.revalidate() } }
            }
            .onReceive(Timer.publish(every: 20, on: .main, in: .common).autoconnect()) { _ in
                Task { await pantherSession.revalidate() }
            }
            .onChange(of: pantherSession.role) { newRole in
                if newRole == nil {
                    selectedPatchGame = nil
                    if calculatorUnlocked { calculatorUnlocked = false }
                }
            }
            .onOpenURL { url in
                if pantherSession.role == "admin" { patchDraftCoordinator.presentImport(url) }
            }
        }
    }
}


// Calculadora funcional: la secuencia exacta 052009 abre la pantalla de keys.
// Los ceros iniciales se conservan al introducirlos.
private struct PantherCalculatorView: View {
    @ObservedObject var session: PantherSession
    @State private var display = "0"
    @State private var typed = ""
    @State private var left: Double?
    @State private var op: String?
    @State private var newNumber = true
    @State private var pastedKey: String?
    @State private var pendingExpression = ""
    @State private var showHistory = false
    @State private var showModes = false
    @State private var mini = false
    @State private var mode = "Básica"
    @State private var notes = ""
    @State private var unit = "cm"
    @State private var convertAmount = "1"
    @AppStorage("panther.calculator.history.v2") private var historyData = "[]"
    @AppStorage("panther.calculator.notes.v2") private var savedNotes = ""
    private let orange = Color(red: 1, green: 0.59, blue: 0)
    private let cyanAccent = Color.cyan
    private let keys = [["⌫", "AC", "%", "÷"], ["7", "8", "9", "×"], ["4", "5", "6", "−"], ["1", "2", "3", "+"], ["+/-", "0", ".", "="]]
    private var history: [String] {
        (try? JSONDecoder().decode([String].self, from: Data(historyData.utf8))) ?? []
    }
    var body: some View {
        GeometryReader { geo in
            let gap: CGFloat = 12
            let size = min((geo.size.width - 40 - 3 * gap) / 4, max(48, (geo.size.height - (mode == "Básica" ? 230 : 370)) / 5.4))
            ZStack {
                TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { timeline in
                    let tm = timeline.date.timeIntervalSinceReferenceDate
                    Image("GhostKeyBackground")
                        .resizable()
                        .scaledToFill()
                        .scaleEffect(1.06 + 0.018 * sin(tm * 1.3))
                        .offset(x: 8 * sin(tm * 1.1), y: 6 * cos(tm * 0.95))
                        .ignoresSafeArea()
                        .overlay(Color.black.opacity(0.55))
                }

                VStack(spacing: 10) {
                    // Cabecera SENSI OG
                    HStack(spacing: 12) {
                        Button { showHistory = true } label: {
                            Image(systemName: "clock.arrow.circlepath")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(width: 46, height: 46)
                                .background(Color.white.opacity(0.08), in: Circle())
                                .overlay(Circle().stroke(Color.cyan.opacity(0.55), lineWidth: 1.2))
                        }
                        .buttonStyle(.plain)

                        Spacer()

                        Text("SENSI OG")
                            .font(.system(size: 18, weight: .heavy, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(colors: [.cyan, .white], startPoint: .leading, endPoint: .trailing)
                            )
                            .shadow(color: .cyan.opacity(0.5), radius: 6)

                        Spacer()

                        Button { showModes = true } label: {
                            Image(systemName: "slider.horizontal.3")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(width: 46, height: 46)
                                .background(Color.white.opacity(0.08), in: Circle())
                                .overlay(Circle().stroke(Color.cyan.opacity(0.55), lineWidth: 1.2))
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 10)

                    // Display
                    VStack(alignment: .trailing, spacing: 6) {
                        if !pendingExpression.isEmpty && pastedKey == nil {
                            Text(pendingExpression)
                                .font(.system(size: 20, weight: .medium, design: .rounded))
                                .foregroundColor(Color.cyan.opacity(0.75))
                        }
                        Text(pastedKey == nil ? display : "••••••••")
                            .font(.system(size: mini ? 44 : 72, weight: .light, design: .rounded))
                            .lineLimit(1).minimumScaleFactor(0.35)
                            .monospacedDigit()
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                            .contentShape(Rectangle())
                            .onTapGesture(count: 2) { paste() }
                            .contextMenu {
                                Button("Pegar") { paste() }
                                if pastedKey == nil { Button("Copiar") { UIPasteboard.general.string = display } }
                            }
                        if pastedKey != nil, let message = session.errorMessage {
                            Text(message)
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(.red)
                                .multilineTextAlignment(.trailing)
                                .frame(maxWidth: .infinity, alignment: .trailing)
                        }
                    }
                    .padding(.horizontal, 22)
                    .padding(.vertical, 14)
                    .background(
                        RoundedRectangle(cornerRadius: 22)
                            .fill(Color.white.opacity(0.05))
                            .overlay(
                                RoundedRectangle(cornerRadius: 22)
                                    .stroke(Color.cyan.opacity(0.25), lineWidth: 1)
                            )
                    )
                    .padding(.horizontal, 16)

                    if mode == "Científica" { scientificPanel }
                    if mode == "Notas matemáticas" { notesPanel }
                    if mode == "Convertir" { convertPanel }

                    Spacer(minLength: 6)

                    // Teclado
                    VStack(spacing: gap) {
                        ForEach(keys.indices, id: \.self) { row in
                            HStack(spacing: gap) {
                                ForEach(keys[row], id: \.self) { key in
                                    Button { tap(key) } label: {
                                        Text(key)
                                            .font(.system(size: mini ? 22 : 28, weight: .medium, design: .rounded))
                                            .frame(width: size, height: size)
                                            .foregroundColor(keyTextColor(key))
                                            .background(
                                                Circle()
                                                    .fill(color(key))
                                                    .shadow(color: keyShadow(key), radius: 6, y: 2)
                                            )
                                            .overlay(
                                                Circle().stroke(keyBorder(key), lineWidth: 1)
                                            )
                                    }.buttonStyle(.plain)
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 18)
                }
            }
        }
        .preferredColorScheme(.dark)
        .tint(.cyan)
        .confirmationDialog("Calculadora", isPresented: $showModes, titleVisibility: .visible) {
            Button("Básica") { mode = "Básica" }
            Button("Científica") { mode = "Científica" }
            Button("Notas matemáticas") { mode = "Notas matemáticas"; notes = savedNotes }
            Button("Convertir") { mode = "Convertir" }
            Button(mini ? "Calculadora normal" : "Mini calculadora") { mini.toggle() }
        }
        .sheet(isPresented: $showHistory) {
            NavigationView {
                List {
                    ForEach(history, id: \.self) { item in
                        Text(item).font(.system(.body, design: .monospaced))
                    }
                }
                .navigationTitle("Historial")
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("Borrar") { historyData = "[]" }
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("Listo") { showHistory = false }
                    }
                }
            }.preferredColorScheme(.dark)
        }
    }
    private var scientificPanel: some View {
        VStack(spacing: 5) {
            ForEach([["sin", "cos", "tan", "√", "x²"], ["π", "e", "ln", "log", "1/x"]], id: \.self) { row in
                HStack(spacing: 6) {
                    ForEach(row, id: \.self) { name in
                        Button(name) { scientific(name) }
                            .font(.system(size: 15))
                            .frame(maxWidth: .infinity).frame(height: 35)
                            .background(Color(white: 0.23), in: RoundedRectangle(cornerRadius: 9))
                    }
                }
            }
        }.padding(.horizontal, 18)
    }
    private var notesPanel: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Notas matemáticas").font(.caption)
            TextEditor(text: $notes)
                .frame(height: 85)
                .background(Color(white: 0.16))
                .onChange(of: notes) { value in savedNotes = value }
            Button("Insertar resultado") { notes += (notes.isEmpty ? "" : "\n") + display }
                .font(.caption).foregroundColor(orange)
        }.padding(.horizontal, 18)
    }
    private var convertPanel: some View {
        VStack(spacing: 8) {
            HStack {
                TextField("Cantidad en metros", text: $convertAmount).keyboardType(.decimalPad)
                    .textFieldStyle(.roundedBorder)
                Picker("Unidad", selection: $unit) {
                    Text("cm").tag("cm"); Text("km").tag("km"); Text("pies").tag("pies")
                }
            }
            let value = Double(convertAmount) ?? 0
            Text("\(String(format: "%.6g", value * (unit == "cm" ? 100 : unit == "km" ? 0.001 : 3.28084))) \(unit)")
                .frame(maxWidth: .infinity, alignment: .trailing)
        }.padding(.horizontal, 18)
    }
    private func color(_ key: String) -> Color {
        if ["÷", "×", "−", "+", "="].contains(key) {
            return Color.cyan.opacity(0.92)
        }
        if ["AC", "+/-", "%", "⌫"].contains(key) {
            return Color.white.opacity(0.16)
        }
        return Color.white.opacity(0.10)
    }
    private func keyTextColor(_ key: String) -> Color {
        if ["÷", "×", "−", "+", "="].contains(key) { return .black }
        return .white
    }
    private func keyBorder(_ key: String) -> Color {
        if ["÷", "×", "−", "+", "="].contains(key) { return Color.cyan.opacity(0.9) }
        return Color.white.opacity(0.12)
    }
    private func keyShadow(_ key: String) -> Color {
        if ["÷", "×", "−", "+", "="].contains(key) { return Color.cyan.opacity(0.45) }
        return Color.black.opacity(0.35)
    }
    private func paste() {
        guard let value = UIPasteboard.general.string?.trimmingCharacters(in: .whitespacesAndNewlines),
              !value.isEmpty else { return }
        pastedKey = value
        session.errorMessage = nil
    }
    private func format(_ x: Double) -> String {
        if !x.isFinite { return "Error" }
        if x == 0 { return "0" }
        if x.rounded() == x && abs(x) < 1e15 { return String(Int64(x)) }
        return String(format: "%.10g", x)
    }
    private func remember(_ expression: String) {
        var items = history
        items.insert(expression, at: 0)
        if let data = try? JSONEncoder().encode(Array(items.prefix(100))),
           let string = String(data: data, encoding: .utf8) { historyData = string }
    }
    private func scientific(_ name: String) {
        guard pastedKey == nil else { return }
        let x = Double(display) ?? 0
        let result: Double
        switch name {
        case "sin": result = sin(x * .pi / 180)
        case "cos": result = cos(x * .pi / 180)
        case "tan": result = tan(x * .pi / 180)
        case "√": result = x >= 0 ? sqrt(x) : .nan
        case "x²": result = x * x
        case "π": result = .pi
        case "e": result = exp(1)
        case "ln": result = x > 0 ? log(x) : .nan
        case "log": result = x > 0 ? log10(x) : .nan
        default: result = x == 0 ? .nan : 1 / x
        }
        display = format(result); typed = display; newNumber = true
    }
    private func tap(_ key: String) {
        if let license = pastedKey {
            if key == "=" && !session.isLoading {
                Task {
                    await session.activate(key: license)
                }
            } else if key == "AC" || key == "⌫" {
                pastedKey = nil
                session.errorMessage = nil
                display = "0"; typed = ""; newNumber = true
            }
            return
        }
        if key.count == 1, let digit = key.first, digit.isNumber {
            if newNumber || display == "Error" { typed = ""; newNumber = false }
            if typed.filter({ $0.isNumber }).count >= 15 { return }
            typed = typed == "0" ? key : typed + key
            display = typed
            return
        }
        switch key {
        case "AC":
            display = "0"; typed = ""; left = nil; op = nil; newNumber = true; pendingExpression = ""
        case "⌫":
            if !newNumber { typed = String(typed.dropLast()); display = typed.isEmpty ? "0" : typed }
        case ".":
            if newNumber { typed = "0"; newNumber = false }
            if !typed.contains(".") { typed += "."; display = typed }
        case "+/-":
            if let x = Double(display) { display = format(-x); typed = display; newNumber = false }
        case "%":
            if let x = Double(display) { display = format(x / 100); typed = display; newNumber = false }
        case "+", "−", "×", "÷":
            left = Double(display); op = key; newNumber = true
            pendingExpression = display + " " + key
        case "=":
            guard let a = left, let b = Double(display), let operation = op else { return }
            let result: Double
            switch operation {
            case "+": result = a + b
            case "−": result = a - b
            case "×": result = a * b
            default: result = b == 0 ? .nan : a / b
            }
            let value = format(result)
            remember("\(format(a)) \(operation) \(format(b)) = \(value)")
            display = value; typed = value; left = nil; op = nil; newNumber = true; pendingExpression = ""
        default: break
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}


// MARK: - Panther iOS license API (Lovable)
@MainActor
final class PantherSession: ObservableObject {
    @Published var role: String?
    @Published var expiresAt: Date?
    @Published var permanent = false
    @Published var expiredNotice = false
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var publishedPatches: [PantherPatch] = []
    @Published var catalogMessage: String?
    @Published var catalogLoading = false

    private let apiBase = (Bundle.main.object(forInfoDictionaryKey: "PantherAPIBaseURL") as? String ?? "")
        .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    // The key is saved in the iOS Keychain, never in a public app resource.
    private let savedKeyService = "PantherIOS.ActiveLicense"
    private let savedKeyAccount = "current-device"
    private var activeKey: String?
    // Keys generadas por el panel SENSI OG (formato portable OG-ID-EXP-DEVICES-SIG).
    // Se validan localmente con el mismo algoritmo del generador HTML.
    private var isUsingPortableKey: Bool {
        guard let k = activeKey else { return false }
        return k.hasPrefix("OG-")
    }

    /// Hash FNV-1a 32-bit compatible con el generador HTML (SENSI_OG_API_Key.html)
    private func fnv1a32(_ str: String) -> String {
        var h: UInt32 = 2166136261
        for byte in str.utf8 {
            h ^= UInt32(byte)
            h = h &* 16777619
        }
        return String(format: "%08x", h)
    }

    /// Valida una key del formato: OG-{id}-{expB36}-{devices}-{sig}
    /// Retorna (ok, expiryDate, maxDevices, errorMessage)
    private func validatePortableKey(_ key: String) -> (Bool, Date?, Int, String?) {
        let parts = key.split(separator: "-").map(String.init)
        // OG + id + expB36 + devices + sig  → 5 partes
        guard parts.count == 5, parts[0] == "OG" else {
            return (false, nil, 0, "Formato de key inválido.")
        }
        let id = parts[1]
        let expB36 = parts[2]
        let devicesStr = parts[3]
        let sig = parts[4].uppercased()

        guard let devices = Int(devicesStr), devices >= 1, devices <= 50 else {
            return (false, nil, 0, "Dispositivos inválidos en la key.")
        }
        // expB36 es el timestamp en base 36
        guard let expMs = UInt64(expB36, radix: 36) else {
            return (false, nil, 0, "Fecha de expiración inválida.")
        }
        let expiry = Date(timeIntervalSince1970: TimeInterval(expMs) / 1000.0)
        if expiry <= Date() {
            return (false, expiry, devices, "La key ha vencido.")
        }

        // Firma: hash(id + "." + expMs + "." + devices + ".SENSI-OG-CORE-2026").slice(0,6)
        let payload = "\(id).\(expMs).\(devices).SENSI-OG-CORE-2026"
        let expectedSig = String(fnv1a32(payload).prefix(6)).uppercased()
        guard sig == expectedSig else {
            return (false, nil, 0, "Firma de key inválida. Solo se aceptan keys del panel SENSI OG.")
        }
        return (true, expiry, devices, nil)
    }

    private func saveKey(_ key: String) {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: savedKeyService,
                                    kSecAttrAccount as String: savedKeyAccount]
        SecItemDelete(query as CFDictionary)
        var item = query
        item[kSecValueData as String] = Data(key.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        let status = SecItemAdd(item as CFDictionary, nil)
        if status != errSecSuccess { print("Could not save license in Keychain: \(status)") }
    }

    private func readSavedKey() -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: savedKeyService,
                                    kSecAttrAccount as String: savedKeyAccount,
                                    kSecReturnData as String: true,
                                    kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func clearSavedKey() {
        SecItemDelete([kSecClass as String: kSecClassGenericPassword,
                       kSecAttrService as String: savedKeyService,
                       kSecAttrAccount as String: savedKeyAccount] as CFDictionary)
    }

    func restoreSavedKey() async {
        guard role == nil, !isLoading, let saved = readSavedKey() else { return }
        await activate(key: saved)
        // If revoked or expired, require a new key on the next launch.
        if role == nil, let errorMessage,
           errorMessage.contains("revocada") || errorMessage.contains("vencid") || errorMessage.contains("no existe") || errorMessage.contains("otro dispositivo") {
            clearSavedKey()
        }
    }
    private var deviceID: String {
        UIDevice.current.identifierForVendor?.uuidString ?? "unavailable-device"
    }

    private func post(_ path: String, key: String) async throws -> (Data, Int) {
        guard let url = URL(string: apiBase + path), url.scheme == "https" else {
            throw PantherAPIError.message("La URL HTTPS del servidor SENSI OG no está configurada.")
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: ["key": key, "device_id": deviceID])
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw PantherAPIError.message("Respuesta HTTP no válida.")
        }
        return (data, http.statusCode)
    }

    private func message(_ data: Data, status: Int) -> String {
        let body = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        let code = body["error"] as? String ?? ""
        switch code {
        case "invalid_key": return "La key no existe."
        case "device_mismatch": return "Esta key está vinculada a otro dispositivo."
        case "revoked": return "Esta key fue revocada."
        case "expired": return "La key ha vencido."
        case "not_activated": return "La key aún no está activada."
        case "invalid_request": return "La key o el identificador del dispositivo no es válido."
        default: return "El servidor rechazó la solicitud (HTTP \(status))."
        }
    }

    func activate(key: String) async {
        let enteredKey = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !enteredKey.isEmpty else { errorMessage = "Introduce una key."; return }

        // 1) Keys portables generadas por el panel SENSI OG (OG-ID-EXP-DEVICES-SIG)
        //    Validación local de firma + expiración. Si hay servidor, también respeta
        //    revocación y límite de dispositivos (max devices).
        if enteredKey.hasPrefix("OG-") {
            let (ok, expiry, _, err) = validatePortableKey(enteredKey)
            if !ok {
                errorMessage = err ?? "Key inválida."
                return
            }

            isLoading = true
            errorMessage = nil
            defer { isLoading = false }

            // Intentar validar con el servidor (revocación + límite de dispositivos)
            if !apiBase.isEmpty {
                do {
                    let (data, status) = try await post("/api/activate", key: enteredKey)
                    if status == 403 {
                        // Servidor rechazó: revocada, exceso de dispositivos, etc.
                        errorMessage = message(data, status: status)
                        return
                    }
                    if (200...299).contains(status),
                       let result = try? JSONDecoder().decode(PantherActivationResponse.self, from: data),
                       result.ok {
                        expiresAt = result.expiry ?? expiry
                        permanent = result.permanent == true
                        expiredNotice = false
                        activeKey = enteredKey
                        saveKey(enteredKey)
                        role = "patches"
                        errorMessage = nil
                        catalogMessage = nil
                        PantherFeedbackAudio.play("welcome_baby")
                        await refreshCatalog()
                        return
                    }
                } catch {
                    // Sin servidor / error de red → continuar en modo offline
                }
            }

            // Modo offline (sin servidor o servidor no alcanzable)
            expiresAt = expiry
            permanent = false
            expiredNotice = false
            activeKey = enteredKey
            saveKey(enteredKey)
            role = "patches"
            errorMessage = nil
            catalogMessage = "Key SENSI OG activa. Con servidor se aplica revocación y límite de dispositivos."
            PantherFeedbackAudio.play("welcome_baby")
            await refreshCatalog()
            return
        }

        // 2) Fallback: validación remota (servidor Render / admin keys)
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            let (data, status) = try await post("/api/activate", key: enteredKey)
            guard (200...299).contains(status) else {
                errorMessage = message(data, status: status)
                return
            }
            let result = try JSONDecoder().decode(PantherActivationResponse.self, from: data)
            guard result.ok else { errorMessage = "La API no autorizó el acceso."; return }
            let isAdmin = result.role == "admin" && result.menus.contains("all")
            let isUser = result.role == "user" && result.menus.contains("patches")
            guard isAdmin || isUser else { errorMessage = "Permisos de acceso desconocidos."; return }
            guard result.permanent == true || result.expiry != nil else { errorMessage = "El servidor no devolvió la fecha de vencimiento."; return }
            if let date = result.expiry, date <= Date(), result.permanent != true { errorMessage = "Key vencida."; return }
            expiresAt = result.expiry
            permanent = result.permanent == true
            expiredNotice = false
            activeKey = enteredKey
            saveKey(enteredKey)
            role = isAdmin ? "admin" : "patches"
            PantherFeedbackAudio.play("welcome_baby")
            await refreshCatalog()
        } catch {
            errorMessage = "No se pudo verificar la key: \(error.localizedDescription). Usa una key generada por el panel SENSI OG."
        }
    }

    func checkExpiry() {
        if role != nil && !permanent, let expiresAt, Date() >= expiresAt { signOut(expired: true) }
    }
    func revalidate() async {
        guard let activeKey, role != nil else { return }
        // Keys portables OG-: primero firma local, luego servidor (revocación / dispositivos)
        if isUsingPortableKey {
            let (ok, expiry, _, _) = validatePortableKey(activeKey)
            if !ok {
                signOut(expired: true)
                return
            }
            expiresAt = expiry
            // Si hay servidor, comprobar si fue revocada o se superó el límite de dispositivos
            if !apiBase.isEmpty {
                do {
                    let (data, status) = try await post("/api/activate", key: activeKey)
                    if status == 403 {
                        // Revocada o exceso de dispositivos → sacar al usuario
                        signOut(expired: true)
                        return
                    }
                    if (200...299).contains(status),
                       let result = try? JSONDecoder().decode(PantherActivationResponse.self, from: data),
                       result.ok {
                        expiresAt = result.expiry ?? expiry
                        permanent = result.permanent == true
                    }
                } catch {
                    // Sin red → solo se aplica la expiración local
                }
            }
            checkExpiry()
            return
        }
        do {
            let (data, status) = try await post("/api/activate", key: activeKey)
            guard (200...299).contains(status) else {
                let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
                signOut(expired: (obj?["error"] as? String) == "expired")
                return
            }
            let result = try JSONDecoder().decode(PantherActivationResponse.self, from: data)
            guard result.ok, result.permanent == true || result.expiry != nil else { signOut(); return }
            expiresAt = result.expiry
            permanent = result.permanent == true
            checkExpiry()
        } catch { checkExpiry() }
    }
    func refreshCatalog() async {
        guard let activeKey else { return }
        // Con keys portables intentamos el catálogo remoto; si falla, no es error crítico
        catalogLoading = true
        catalogMessage = nil
        defer { catalogLoading = false }
        do {
            let (data, status) = try await post("/api/patches", key: activeKey)
            guard (200...299).contains(status) else {
                if isUsingPortableKey {
                    catalogMessage = "Catálogo remoto no disponible (servidor offline). La key sigue activa."
                } else {
                    catalogMessage = message(data, status: status)
                }
                return
            }
            let result = try JSONDecoder().decode(PantherPatchResponse.self, from: data)
            guard result.ok else { catalogMessage = "El catálogo no está disponible."; return }
            publishedPatches = result.patches
            if result.patches.isEmpty { catalogMessage = "No hay patches publicados todavía." }
        } catch {
            if isUsingPortableKey {
                catalogMessage = "Catálogo remoto no disponible. La key SENSI OG sigue activa."
            } else {
                catalogMessage = "No se pudo actualizar el catálogo: \(error.localizedDescription)"
            }
        }
    }

    // Descarga autenticada: el servidor debe validar key + dispositivo en cada solicitud.
    func downloadPatch(_ patch: PantherPatch) async throws -> URL {
        guard let activeKey else { throw PantherAPIError.message("Inicia sesión con una key válida.") }
        // Las keys portables permiten acceso a la app; las descargas de patches siguen necesitando servidor
        if isUsingPortableKey {
            // Intentamos igual; si el servidor no está, fallará con mensaje claro
        }
        guard let identifier = patch.id.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) else {
            throw PantherAPIError.message("Identificador de patch inválido.")
        }
        let (data, status) = try await post("/api/patches/\(identifier)/download", key: activeKey)
        guard (200...299).contains(status) else { throw PantherAPIError.message(message(data, status: status)) }
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("PantherRemotePatches", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let filename = UUID().uuidString + ".3105"
        let destination = directory.appendingPathComponent(filename)
        try data.write(to: destination, options: [.atomic, .completeFileProtection])
        return destination
    }

    func signOut(expired: Bool = false) {
        clearSavedKey()
        expiredNotice = expired
        expiresAt = nil
        permanent = false
        publishedPatches = []
        catalogMessage = nil
        role = nil
        activeKey = nil
        errorMessage = nil
    }
}

private enum PantherAPIError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        if case .message(let value) = self { return value }
        return nil
    }
}

private struct PantherActivationResponse: Decodable {
    let ok: Bool
    let role: String
    let menus: [String]
    let expires_at: String?
    let expires_at_ms: Double?
    let permanent: Bool?
    var expiry: Date? {
        if let expires_at_ms { return Date(timeIntervalSince1970: expires_at_ms / 1000) }
        guard let expires_at else { return nil }
        if let n = Double(expires_at) { return Date(timeIntervalSince1970: n > 10_000_000_000 ? n / 1000 : n) }
        let parser = ISO8601DateFormatter()
        if let date = parser.date(from: expires_at) { return date }
        parser.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return parser.date(from: expires_at)
    }
}

private struct PantherPatchResponse: Decodable {
    let ok: Bool
    let patches: [PantherPatch]
}

struct PantherPatch: Decodable, Identifiable {
    let id: String
    let name: String
    let description: String?
    let version: String?
    let category: String?
    let download_url: String?
}
private struct PantherNeonBrand: View {
    var body: some View {
        HStack(spacing: 6) {
            Image("PantherAppMark")
                .resizable()
                .scaledToFit()
                .frame(width: 59, height: 59)
                .clipShape(Circle())
            Text("SENSI OG")
                .font(.system(size: 37, weight: .bold, design: .serif))
                .italic()
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.75)
        }
        .shadow(color: .cyan.opacity(0.9), radius: 8)
        .accessibilityElement(children: .combine)
    }
}

private struct PantherLoginView: View {
    @ObservedObject var session: PantherSession
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var key = ""

    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .topLeading) {
                Color.black
                TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: reduceMotion)) { timeline in
                    let t = timeline.date.timeIntervalSinceReferenceDate
                    Image("GhostKeyBackground")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 390, height: 844)
                        .scaleEffect(reduceMotion ? 1.04 : 1.04 + 0.014 * sin(t * 1.8))
                        .offset(x: reduceMotion ? 0 : 6 * sin(t * 1.5),
                                y: reduceMotion ? 0 : 5 * sin(t * 2.0))
                        .frame(width: 390, height: 844)
                        .clipped()
                }
                PantherNeonBrand()
                    .frame(width: 350, height: 68)
                    .position(x: 195, y: 365)

                HStack(spacing: 12) {
                    Image(systemName: "key.fill")
                        .font(.system(size: 21))
                        .foregroundStyle(.white)
                    Rectangle()
                        .fill(Color.cyan.opacity(0.7))
                        .frame(width: 1, height: 27)
                    TextField("", text: $key,
                              prompt: Text("Ingresa tu Key")
                                .foregroundColor(.white.opacity(0.38)))
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .foregroundStyle(.white)
                        .font(.system(size: 20, weight: .medium))
                }
                .padding(.horizontal, 20)
                .frame(width: 350, height: 57)
                .background(Color.black.opacity(0.86), in: RoundedRectangle(cornerRadius: 19))
                .overlay(RoundedRectangle(cornerRadius: 19).stroke(Color.cyan, lineWidth: 2))
                .shadow(color: .cyan.opacity(0.75), radius: 8)
                .position(x: 195, y: 447)

                // The error is fixed between the input and button, so it never moves controls.
                Group {
                    if session.expiredNotice {
                        Text("Key vencida")
                    } else if let message = session.errorMessage {
                        Text(message)
                    }
                }
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(.orange)
                .lineLimit(2)
                .multilineTextAlignment(.center)
                .frame(width: 340, height: 34)
                .position(x: 195, y: 492)

                Button {
                    Task { await session.activate(key: key) }
                } label: {
                    Label(session.isLoading ? "Verificando..." : "Entrar",
                          systemImage: "rectangle.portrait.and.arrow.right")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 275, height: 57)
                        .background(Color.black.opacity(0.85), in: RoundedRectangle(cornerRadius: 19))
                        .overlay(RoundedRectangle(cornerRadius: 19).stroke(Color.cyan, lineWidth: 2))
                        .shadow(color: .cyan.opacity(0.9), radius: 9)
                }
                .disabled(session.isLoading)
                .position(x: 195, y: 550)

                Text("¿No tienes una Key?")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white)
                    .position(x: 195, y: 685)

                Link(destination: URL(string: "https://t.me/SENSIOGCUBA")!) {
                    Label("Únete a mi Telegram", systemImage: "paperplane.fill")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(.cyan)
                        .frame(width: 320, height: 52)
                        .background(Color.black.opacity(0.85), in: Capsule())
                        .overlay(Capsule().stroke(Color.cyan, lineWidth: 2))
                        .shadow(color: .cyan.opacity(0.6), radius: 7)
                }
                .position(x: 195, y: 735)
            }
            .frame(width: 390, height: 844)
            .scaleEffect(x: proxy.size.width / 390,
                         y: proxy.size.height / 844,
                         anchor: .topLeading)
            .frame(width: proxy.size.width, height: proxy.size.height, alignment: .topLeading)
        }
        .ignoresSafeArea()
        .statusBarHidden(true)
    }
}

// Normal keys use the same original patch project interface as the administrator.
// No per-key patch assignments, online catalog or separate package viewer.
private struct PantherAssignedPatchesView: View {
    @ObservedObject var session: PantherSession
    let gameMode: PatchGameMode
    var onBack: (() -> Void)? = nil

    var body: some View {
        PatchProjectsView(ghostTheme: true, gameMode: gameMode, onBack: onBack)
            .background(Color.black.ignoresSafeArea())
            .statusBarHidden(true)
    }
}

private struct PatchGameSelectorView: View {
    let onSelect: (PatchGameMode) -> Void

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { timeline in
                    let tm = timeline.date.timeIntervalSinceReferenceDate
                    Image("GhostPatchesBackground")
                        .resizable().scaledToFill()
                        .frame(width: geometry.size.width * 1.12, height: geometry.size.height * 1.12)
                        .scaleEffect(1.04 + 0.02 * sin(tm * 1.4))
                        .offset(x: 10 * sin(tm * 1.15), y: 8 * cos(tm * 0.95))
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        .clipped()
                        .overlay(Color.black.opacity(0.48))
                }
                VStack(spacing: 22) {
                    Spacer()
                    HStack(spacing: 9) {
                        Image("SensiOGMark").resizable().scaledToFill()
                            .frame(width: 52, height: 52).clipShape(Circle())
                            .overlay(Circle().stroke(Color.cyan, lineWidth: 2))
                        Text("SENSI OG").font(.system(size: 38, weight: .bold, design: .serif))
                            .italic().foregroundStyle(.white)
                    }
                    .shadow(color: .cyan, radius: 10)
                    Text("SELECCIONA TU JUEGO")
                        .font(.system(size: 19, weight: .heavy)).foregroundStyle(.white)
                        .shadow(color: .cyan, radius: 6)
                    gameButton(title: "FREE FIRE NORMAL", subtitle: "Menú de parches independiente", mode: .normal)
                    gameButton(title: "FREE FIRE MAX", subtitle: "Menú de parches actual", mode: .max)
                    Spacer()
                    Text("SENSI OG").font(.system(size: 11, weight: .semibold)).foregroundStyle(.white.opacity(0.6))
                }
                .padding(.horizontal, 24).padding(.vertical, 34)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .ignoresSafeArea()
        }
        .background(Color.black.ignoresSafeArea())
        .statusBarHidden(true)
    }

    private func gameButton(title: String, subtitle: String, mode: PatchGameMode) -> some View {
        Button { onSelect(mode) } label: {
            HStack(spacing: 14) {
                Image(systemName: "gamecontroller.fill")
                    .font(.system(size: 30, weight: .bold)).foregroundStyle(.cyan)
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.system(size: 18, weight: .heavy)).foregroundStyle(.white)
                    Text(subtitle).font(.system(size: 12, weight: .medium)).foregroundStyle(.white.opacity(0.78))
                }
                Spacer()
                Image(systemName: "chevron.right.circle.fill").font(.system(size: 27)).foregroundStyle(.cyan)
            }
            .padding(.horizontal, 18).frame(maxWidth: .infinity, minHeight: 88)
            .background(Color.black.opacity(0.84), in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.cyan, lineWidth: 2))
            .shadow(color: .cyan.opacity(0.55), radius: 8)
        }
        .buttonStyle(.plain)
    }
}
